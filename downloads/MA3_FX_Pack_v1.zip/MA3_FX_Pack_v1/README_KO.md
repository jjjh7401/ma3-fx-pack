# MA3 FX Pack v1 — 설치 안내

페이저 200 · 색 60 · 위상(MAtricks) 12. 설치기 파일 하나가 **여러분 쇼의 장비로** 프리셋을 만듭니다(grandMA3 2.4.2 이상). 밝기·무빙·빔은 범용(Universal), 색이 든 것은 Global(그 쇼 장비 종류 전부). 새 종류 장비를 더하면 설치기를 한 번 더 실행하세요.

## 설치
1. 먼저 쇼에 장비를 패치합니다.
2. `MA3_FX_PACK_INSTALLER.xml` 을 plugins 폴더에 넣습니다.
   - onPC(macOS): `~/MALightingTechnology/gma3_library/datapools/plugins/`
   - onPC(Windows): `C:\ProgramData\MALightingTechnology\gma3_library\datapools\plugins\`
   - 콘솔: USB 메모리 `gma3_library/datapools/plugins/` 에 넣고 → Plugins 풀 빈 칸에서 Import → 드라이브 USB
3. 명령줄(플러그인 칸 99 가 차 있으면 빈 번호로):
   ```
   Import Plugin 99 'MA3_FX_PACK_INSTALLER' /NoConfirmation
   Plugin 99
   ```
4. 확인 창 OK → 「272 / 272 설치됨」. 설치기는 저장 전 재생 중인 시퀀스·타임코드를 끕니다(공연 중 실행 금지). 쇼를 저장하면 남습니다.

## 번호
밝기 1.9501–1.9550 · 무빙 2.9501–2.9550 · 색 흐름 4.9601–4.9660 · 색 60 4.9501–4.9560 · 빔·섞음 21.9501–21.9540 · MAtricks 9501–9512

## 쓰는 법
1. 속도 = Speed Master 15 → `Master 3.15 At BPM 120`
2. 위상(MAtricks)은 프리셋 다음에(선택 순서가 위상 기준 — 왼→오른으로 선택)
3. 무빙 프리셋 → 그다음 위치 프리셋(무빙을 부르면 위치가 가운데로)
4. 빠른 번쩍임(DIM STROBE · FLICKER) 은 높은 BPM 에서 초당 3회를 넘을 수 있음 — 광과민 주의

## 확인한 환경
onPC 2.4.2(macOS), 장비 7종 412대 쇼에 272/272 설치·작동 확인. 콘솔 실기·Windows onPC 는 아직 확인 못 함.

무료 · 모든 값은 직접 정의(다른 상품·쇼 파일 내용 없음) · grandMA3 는 MA Lighting 의 상표 · 사용 결과에 대한 책임은 사용자에게 있음.
