# MA3 FX Pack v1 — Install guide

200 phasers · 60 colors · 12 MAtricks. One installer file builds universal presets **from the fixtures in your own show** (grandMA3 2.4.2 or later).

## Install
1. Patch your fixtures first.
2. Put `MA3_FX_PACK_INSTALLER.xml` into the plugins folder:
   - onPC (macOS): `~/MALightingTechnology/gma3_library/datapools/plugins/`
   - onPC (Windows): `C:\ProgramData\MALightingTechnology\gma3_library\datapools\plugins\`
   - Console: USB stick `gma3_library/datapools/plugins/` → Import into an empty Plugins pool slot → choose the USB drive
3. Command line (use any empty plugin number if 99 is taken):
   ```
   Import Plugin 99 'MA3_FX_PACK_INSTALLER' /NoConfirmation
   Plugin 99
   ```
4. Press OK → “272 / 272 installed”. Before storing, the installer switches off running sequences and timecodes (don't run it during a show). Save your show to keep the pack.

## Numbers
Dimmer 1.9501–1.9550 · Movement 2.9501–2.9550 · Color FX 4.9601–4.9660 · Colors 4.9501–4.9560 · Beam/Mix 21.9501–21.9540 · MAtricks 9501–9512

## Usage
1. Speed = Speed Master 15 → `Master 3.15 At BPM 120`
2. Apply MAtricks after the preset (phase follows selection order — select left to right)
3. Movement preset first, then your position preset (calling a movement recenters the position)
4. Fast flashes (DIM STROBE, FLICKER) can exceed 3 Hz at high BPM — mind photosensitive audiences

## Tested
onPC 2.4.2 (macOS): 272/272 installed and verified in a show with 7 fixture types / 412 fixtures. Console hardware and Windows onPC not tested yet.

Free · all values are original (nothing copied from other packs or show files) · grandMA3 is a trademark of MA Lighting · use at your own risk.
